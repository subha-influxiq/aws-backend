/**
 * Generated bundle index. Do not edit.
 */
export * from './public-api';
export { ApiService as ɵa } from './lib/api.service';
export { DemoMaterialModule as ɵb } from './lib/materialmodules';
